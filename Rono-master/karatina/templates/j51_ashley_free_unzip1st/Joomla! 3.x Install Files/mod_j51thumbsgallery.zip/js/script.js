(function($) {"use strict";
	$(document).ready(function() {
		baguetteBox.run('.gallery');
	});
})(jQuery);
