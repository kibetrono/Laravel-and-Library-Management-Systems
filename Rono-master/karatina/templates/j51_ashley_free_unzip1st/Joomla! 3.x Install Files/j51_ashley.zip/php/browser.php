<?php
defined( '_JEXEC' ) or die( 'Restricted index access' );?>   


<!--[if IE 7]>
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/css/ie7.css" rel="stylesheet" type="text/css" />
<![endif]-->

<!--[if IE 6]>
<script type="text/javascript" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template ?>/js/fix-png-ie6.js"></script>
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/css/ie6.css" rel="stylesheet" type="text/css" />
<script src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/js/ie6/warning.js"></script><script>window.onload=function(){e("<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/js/ie6/")}</script>
<![endif]-->
