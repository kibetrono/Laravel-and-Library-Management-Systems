<?php if ($this->countModules( 'breadcrumb' )) : ?>
<div id="breadcrumb" class="block_holder">
        <jdoc:include type="modules" name="breadcrumb" style="mod_standard" />
    <div class="clear"></div>
</div>
<?php endif; ?>