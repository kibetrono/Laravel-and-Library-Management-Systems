ALTER TABLE #__djimageslider 
CHANGE `description` `description` text DEFAULT NULL,
CHANGE `params` `params` text DEFAULT NULL;
